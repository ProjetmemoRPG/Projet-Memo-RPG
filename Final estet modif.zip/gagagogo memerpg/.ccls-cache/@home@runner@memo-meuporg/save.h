#include "whatif.h"

int sizeOfSave();

void saveplayer(player* Players, int n);

void manageScores(player* tabPlayerInGame, int n);

void displaysTenBscores();

player playerCreator();

