#include "save.h"

char myDirection(placement* tempPos){
    char input;
    printf("choisire une direction:\n");
    scanfChar(&input);
    return input;
}

placement select_card(player pl,carte** map){
    placement selectPosition = pl.position;
    placement* p = &selectPosition;
    char input = 0;
    do{
        printf("your pose : %d , %d\n",selectPosition.x, selectPosition.y);
        (map[selectPosition.y][selectPosition.x]).colorOut = pl.color;
        
        afichage(map,&pl);
        croixDirectionnelle();
        input = myDirection(p);
        (map[selectPosition.y][selectPosition.x]).colorOut = 0;
        
        if(input == 'z'){
            if((selectPosition.x-1)>=0){
                printf("%d",selectPosition.y-1);
                selectPosition.x--;
            }
        }
        else if(input == 's'){
            if((selectPosition.x+1)<=LARG){
                printf("%d",selectPosition.y+1);
                selectPosition.x++;
            }  
        }
        else if(input == 'q'){
            if((selectPosition.y-1)>=0){
                printf("%d",selectPosition.x-1);
                selectPosition.y--;
            }
        }
        else if(input == 'd'){
            if((selectPosition.y+1)<LARG){
                printf("%d",selectPosition.x+1);
                selectPosition.y++;
            }
        }
        
        
    }while(input != 'v');
    return selectPosition;
}


void moving(player* plP, carte** map){
    player pl = *plP;
    short endMooving = 0;
    placement posTemp;
    do{
        printf("start dowhile\n");
        posTemp = select_card(pl, map);
        /*
        if(map[posTemp.x][posTemp.y].reveal == 1){
            printf("position selctioner déja visité, recomencer\n");
        }
        */
        if((map[pl.position.x][pl.position.y].content != 'P')&&(((pl.position.x != posTemp.x)&&(pl.position.y != posTemp.y))&&((abs(pl.position.x - posTemp.x)!=1)&&(abs(pl.position.y - posTemp.y)!=1)))){
                printf("%d\n",abs(pl.position.x - posTemp.x));
                printf("%d\n",abs(pl.position.y - posTemp.y));
                printf("position non valide, recomencer\n");
                (map[posTemp.x][posTemp.y]).colorOut = 0;
            }
        
        else{
            printf("position validé\n");
            endMooving=1;
            (*plP).position = posTemp;
            (map[posTemp.x][posTemp.y]).reveal = 1;
        }
    }while(endMooving==0);
    
    printf("end moving\n");
}


void swap(carte** map,player* plP){
    player fictivPlayer;//variable nécésaire a la séléction des case, pour indiquer a select_card ou commencer
    fictivPlayer.position.x=0;
    fictivPlayer.position.y=0;
    fictivPlayer.color = 31;
    short exitCondition;
    carte tempCarte;
    placement position1, position2;
    
    printf("Vous avez découvert un totem! choiscer les 2 case a échanger entre elle\n");
    do{
        exitCondition = 1;
        position1 = select_card(fictivPlayer,map);//selectionne les 2 position
        system("clear");
        printf("Vous avez découvert un totem! choiscer les 2 case a échanger entre elle\n");
        position2 = select_card(fictivPlayer,map);
        system("clear");
        if((position1.x == position2.x)&&(position1.y == position2.y)){ //vérifie si les 2 case sont pas les meme (peut etre retirer, ca fonctionnera quand meme, juste on poura ne pas swap)
            exitCondition = 0;
            printf("vous avez séléctioner les 2 meme case. veuiller recomencer\n");
        }
        else{ //effectue le swap
            tempCarte = map[position1.x][position1.y];
            map[position1.x][position1.y] = map[position2.x][position2.y];
            map[position2.x][position2.y] = tempCarte;
            exitCondition = 1;
        }
        if((position1.x == (*plP).position.x)&&(position1.y == (*plP).position.y)){ //change la posistion du joueur si il est sur la case swaper
            (*plP).position = position2;
        }
        else if((position2.x == (*plP).position.x)&&(position2.y == (*plP).position.y)){
            (*plP).position = position1;
        }
    }while(exitCondition == 1);
}

short surrounded(carte** map,player pl){
    if((map[pl.position.x][pl.position.y-1].reveal == 1)&&(map[pl.position.x-1][pl.position.y].reveal == 1)&&(map[pl.position.x][pl.position.y+1].reveal == 1)&&(map[pl.position.x+1][pl.position.y].reveal == 1)){
        return 1;
    }
    else{
        return 0;
    }
}

short turn(player* plP, carte** map){
    int buffere;
    printf("début du tours de \n");
    short end_turn = 0;
    do{
        printf("tours de bob\n");
        choixArme(plP);
        moving(plP,map);
        
        if(map[(*plP).position.x][(*plP).position.y].content == 't'){
            swap(map,plP);
        }
        if(Combat(plP,(map[(*plP).position.x][(*plP).position.y]).content,map) == 0){
            end_turn = 1;
        }
        if(surrounded(map, *plP) == 1){
            printf("vous etes encerclé!\n");
            end_turn = 1;
        }
        printf("appuyer sur n'importe quel touche pour continuer");
        scanfInt(&buffere);
        system("clear");
    }while(end_turn == 0);
    
    return  finDujeu(plP);
}
 
void resetPlayer(int nl, player * plP){
    if(nl == 0){
        (*plP).color = 32;
        (*plP).position.x = 1;
        (*plP).position.y = 0;
    }
    if(nl == 1){
        (*plP).color = 34;
        (*plP).position.x = 3;
        (*plP).position.y = 4;
    }
    if(nl == 2){
        (*plP).color = 36;
        (*plP).position.x = 0;
        (*plP).position.y = 3;
    }
    if(nl == 3){
        (*plP).color = 35;
        (*plP).position.x = 4;
        (*plP).position.y = 2;
    }
}



void game(){
    printf("like start\n");
    char buffere;
    short victory;
    int nbPlayer = 0;
    item itemList[LARG*LARG];
    itemList_creator(itemList);
    int i,j;
    player* listPlayer;
    ecranTitre();
    
    do{
        printf("Choisissez le nombre de joueur :\n       2    4\n");
        scanfInt(&nbPlayer);
        if(nbPlayer == 0){
            printf("Regarder vos doigt. conter jusqu'a 2 ou 4.\n");
        }
        printf("%d\n",nbPlayer);
    }while((nbPlayer != 2)&&(nbPlayer != 4));
    
    listPlayer = malloc(nbPlayer*sizeof(player));
    
    for(int i=0;i<nbPlayer;i++){
        listPlayer[i] = playerCreator(i);
        resetPlayer(i,(listPlayer+i));
        printf("i = %d\n",i);
    }
    printf("Initilasiation du jeux...\n");
    system("clear");
    do{
        carte** mainMap = mapSpawning(LARG);
        carte** saveMap = mapSpawning(LARG);
        mapFeeding(saveMap,LARG,itemList,LARG*LARG);
        resetMap(mainMap,saveMap);
        i=0;
        victory=0;
        do{
            printf("tours joueur %s\n",listPlayer[i].name);
            victory = turn(listPlayer+i,mainMap);
            printf("fin du tour de %s\n",listPlayer[i].name);
            
            i++;
            if(i>=nbPlayer){
                i = 0;
            }
            resetMap(mainMap,saveMap);
            resetPlayer(i,listPlayer+i);
            
        }while(victory == 0);
        printf("%s, le joueur %d a gagner",listPlayer[i].name,i);
        listPlayer[i].score++;
        manageScores(listPlayer, nbPlayer);

	    displaysTenBscores();
        free_map(mainMap);
    }while(restart()==1);

    
}