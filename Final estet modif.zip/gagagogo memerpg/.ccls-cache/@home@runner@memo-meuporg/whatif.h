#include "mapper.h"

void choixArme(player* bob);

int Combat(player* bob, char contenuCase, carte** mainMap);

int armeAntique(player* bob, char contenuCase);

int Coffre(player* bob, char contenuCase);

int finDujeu(player* bob);

void croixDirectionnelle();

int ecranTitre();

