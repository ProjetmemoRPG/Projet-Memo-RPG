#include "mapper.h"

void choixRace(player* bob){
printf("Choisissez votre race entre:\n c : le Chevalier\n r : le Ranger\n m : le mage\n v : le Voleur\n"); // Choose what kind of character u want to be.

char race;

do{

    

    scanfChar(&race);

    

    if (race == 'c'){

        (*bob).Race = 'c'; // c = knight

    }

    if (race == 'r'){

        (*bob).Race = 'r'; // r = ranger

    }

    if (race == 'm'){

        (*bob).Race = 'm'; // m = mage

    }

    if (race == 'v'){

        (*bob).Race = 'v'; // v = thief

}
    if((race != 'v')&&(race == 'm')&&(race == 'r')&&(race == 'c')){
    printf("Choix de race erroné.\nVeuillez choisir à nouveau.\n"); // If none of this letters have been choosen, it ask again and you have to choose one more time.
    }
    }while((race != 'c')&&(race != 'r')&&(race != 'm')&&(race != 'v'));
   

}



void choixArme(player* bob){

    

printf("choisissez votre arme parmis\n1: bouclier rÃ©flÃ©chissant\n2: torche\n3: hache de pierre\n4: arc\n"); // Choose which weapon you want to use before a fight.

int arme, booll;
int* armeP = &arme;

do{
    
    scanfInt(armeP);

    if (arme == 1){
        booll = 1;
        (*bob).armeSelect = 1; // If 1, you take a reflective shield.

    }

    else if (arme == 2){
        booll = 1;
        (*bob).armeSelect = 2; // If 2, you take a torch.

    }

    else if (arme == 3){
        booll = 1;
        (*bob).armeSelect = 3; // If 3, you take a stone axe.

    }

    else if (arme == 4){
        booll = 1;
        (*bob).armeSelect = 4; // If 4, you take a bow.

    }
    else{
        printf("Choix d'arme incorrect. \nVeuillez choisir à  nouveau.\n");
        booll = 0;
    }
}while(booll == 0);

         // If none of this number have been selected, it ask again to choose a weapon until you selected a good one.

}

    

    int Combat(player* bob, char contenuCase, carte** mainMap){ // If the player keep the good weapon against the right monster, it clears the box and let the player continue is journey. In other case, his turn ends now.

    

    contenuCase = mainMap[(*bob).position.x][(*bob).position.y].content; 

    if((contenuCase == 'B') && ((*bob).armeSelect == 1)){ // In case of it's a basiliks and the player keep the shield, he can continue.

        mainMap[(*bob).position.x][(*bob).position.y].content = ' ';
        printf("vous avez vaincu un Basilic!\n");    
        return 1;

    }

    else if((contenuCase == 'Z') && ((*bob).armeSelect == 2)){ // In case of it's a zombie and the player keep the torch, he can continue.

        mainMap[(*bob).position.x][(*bob).position.y].content = ' ';
        printf("vous avez vaincu un Zombie!\n");
        return 1;

    }

    else if((contenuCase == 'T') && ((*bob).armeSelect == 3)){ // In case of it's a troll and the player keep the axe, he can continue.

        mainMap[(*bob).position.x][(*bob).position.y].content = ' ';
        printf("vous avez vaincu un Troll!\n");
        return 1;

    }

    else if((contenuCase == 'H') && ((*bob).armeSelect == 4)){ // In case of it's a harpy eagle and the player keep the bow, he can continue.

        mainMap[(*bob).position.x][(*bob).position.y].content = ' ';
        printf("vous avez vaincu un Harppiste!\n");
        return 1;

    }
    else if((contenuCase == 't')||(contenuCase == 'P')||(contenuCase == 'C')||(contenuCase == 'E')||(contenuCase == 'S')||(contenuCase == 'D')||(contenuCase == 'G')){
        printf("vous avez découvert un artéfacte de type %c.\n",mainMap[(*bob).position.x][(*bob).position.y].content);
        return 1;
    }
    else{
        printf("vous avez été batu par un monstre de type %c .\n", mainMap[(*bob).position.x][(*bob).position.y].content);
        return 0; // If combinations are wrong, his turn ends now.

    }

}

int armeAntique(player* bob, char contenuCase){ // Makes the player keep his mythic weapon.

    if((contenuCase == 'E') && ((*bob).Race == 'c')){  // If the box contains an ancient weapon and the playerâ€™s race is a knight and the weapon is the sword of fire, then he takes the weapon.

        (*bob).inventaireArme == 'e';
        printf("vous avez récupéré votre item légandaire!\n");
        return 1;

    }

    if((contenuCase == 'S') && ((*bob).Race == 'r')){  // If the box contains an antique weapon and the playerâ€™s race is a ranger and the weapon is the pet control stick, then he takes the weapon.

        (*bob).inventaireArme == 'b';
        printf("vous avez récupéré votre item légandaire!\n");
        return 1;

    }

    if((contenuCase == 'G') && ((*bob).Race == 'm' )){  // If the box contains an ancient weapon and the playerâ€™s race is a magician and the weapon is the forbidden grimoire, then he takes the weapon.

        (*bob).inventaireArme == 'g';
        printf("vous avez récupéré votre item légandaire!\n");
        return 1;

    }

    if((contenuCase == 'D') && ((*bob).Race == 'v')){  // If the box contains an ancient weapon and the playerâ€™s race is a thief and the weapon is the sleeping dagger, then he takes the weapon.

        (*bob).inventaireArme == 'd';
        printf("vous avez récupéré votre item légandaire!\n");
        return 1;

    }

    else{

        return 0;

    }

}

int Coffre(player* bob, char contenuCase){ // If a chest is found.

    if(contenuCase == 'C' && (*bob).inventaireArme == 0){ // If the player finds a chest whitout having his mythic weapon, he grabs the content of the chest, but he must find his mythic weapon.

       (*bob).inventaireItem == 1;

       return 1;

    }

    else{

        return 0;

    }

}

int finDujeu(player* bob){ // End of the game

    

    if(((*bob).inventaireItem == 1) && (((*bob).inventaireArme == 1 )||((*bob).inventaireArme == 2) || ((*bob).inventaireArme ==3) || ((*bob).inventaireArme ==4))){ // If a player get his chest AND his mythic weapon, he wins the game.

    printf("FELICITATION ! Vous avez gagnÃ© !\n");
    return 1;
    }  
    return 0;
}

    

int restart(){ // Restart game ?

    int restart = 2;

        do{

        printf("Voulez-vous rejouer ?\n1 : Oui.\n 2 : Non."); // Choose 1 to play again and 0 to stop the game.

        scanfInt(&restart);

        if(restart == 1){

            return 1;

        }

        if( restart == 0){

            return 0;

        }

        printf("Je n'ai pas compris. Voulez-vous rejouer ?\n"); // If other than 1 or 2, it will ask you to choose again until you choose a correct answer.

        }

        while(restart != 0 || restart != 1);

}

    

    

    

void croixDirectionnelle(){ // graphic design of the D-pad

printf("              ***********               \n");

printf("              ***  z  ***               \n");

printf("              ***********               \n");

printf("                             \n");

printf("    *******************************     \n");

printf("    ***  q  ***         *** D  ***     \n");

printf("    *******************************   \n");

printf("                         \n");

printf("              ***********               \n");

printf("              ***  S  ***               \n");

printf("              *********** \n");

}

    

    

    

    

int ecranTitre(){   // graphic design of the Tittle Screen.
    char buffer;
    printf(PCOLOR(Y)"-------------------------------------------------------------\n"); printf(PCOLOR(V));

    printf("-                                                           -\n");  printf(PCOLOR(Y));

    printf("-                                                           -\n"); printf(PCOLOR(V));

    printf("-                       "); printf(PCOLOR(C)"*"); printf(PCOLOR(Y)"                                   -\n");

    printf("-                      "); printf(PCOLOR(C)"*"); printf(PCOLOR(Y)"                                    -\n"); printf(PCOLOR(V));

    printf(PCOLOR(V)"-                     "); printf(PCOLOR(C)"*"); printf(PCOLOR(V)"                                     -\n"); printf(PCOLOR(Y));

    printf("-                                                           -\n");  printf(PCOLOR(V));

    printf("-     "); printf(PCOLOR(C)"***     ***  ********  ***     ***       ****"); printf(PCOLOR(V)"         -\n"); printf(PCOLOR(Y));

    printf("-     "); printf(PCOLOR(C)"*  *   *  *  *         *  *   *  *     *      *"); printf(PCOLOR(Y)"       -\n"); printf(PCOLOR(V));

    printf("-     "); printf(PCOLOR(C)"*    *    *  *         *    *    *   *          *"); printf(PCOLOR(V)"     -\n"); printf(PCOLOR(Y));

    printf("-     "); printf(PCOLOR(C)"*         *  *         *         *   *          *"); printf(PCOLOR(Y)"     -\n"); printf(PCOLOR(V));

    printf("-     "); printf(PCOLOR(C)"*         *  ********  *         *   *          *"); printf(PCOLOR(V)"     -\n"); printf(PCOLOR(Y));

    printf("-     "); printf(PCOLOR(C)"*         *  *         *         *   *          *"); printf(PCOLOR(Y)"     -\n"); printf(PCOLOR(V));

    printf("-     "); printf(PCOLOR(C)"*         *  *         *         *   *          *"); printf(PCOLOR(V)"     -\n"); printf(PCOLOR(Y));

    printf("-     "); printf(PCOLOR(C)"*         *  *         *         *     *      *"); printf(PCOLOR(Y)"       -\n"); printf(PCOLOR(V));

    printf("-     "); printf(PCOLOR(C)"*         *  ********  *         *       ****"); printf(PCOLOR(V)"         -\n"); printf(PCOLOR(Y));

    printf("-                                                           -\n"); printf(PCOLOR(V));

    printf("-                                                           -\n"); printf(PCOLOR(Y));

    printf("-                                                           -\n"); printf(PCOLOR(V));

    printf("-                                                           -\n"); printf(PCOLOR(Y));

    printf("-                                                           -\n"); printf(PCOLOR(V));

    printf("-       "); printf(PCOLOR(C)"********       *******          *****"); printf(PCOLOR(V)"               -\n"); printf(PCOLOR(Y));

    printf("-       "); printf(PCOLOR(C)"*       *      *      *       *"); printf(PCOLOR(Y)"                     -\n"); printf(PCOLOR(V));

    printf("-       "); printf(PCOLOR(C)"*        *     *      *     *"); printf(PCOLOR(V)"                       -\n"); printf(PCOLOR(Y));

    printf("-       "); printf(PCOLOR(C)"*       *      *      *   *"); printf(PCOLOR(Y)"                         -\n"); printf(PCOLOR(V));

    printf("-       "); printf(PCOLOR(C)"********       *******    *       ********"); printf(PCOLOR(V)"          -\n"); printf(PCOLOR(Y));

    printf("-       "); printf(PCOLOR(C)"*       *      *          *               *"); printf(PCOLOR(Y)"         -\n"); printf(PCOLOR(V));

    printf("-       "); printf(PCOLOR(C)"*        *     *            *           *"); printf(PCOLOR(V)"           -\n"); printf(PCOLOR(Y));

    printf("-       "); printf(PCOLOR(C)"*         *    *              *       *"); printf(PCOLOR(Y)"             -\n"); printf(PCOLOR(V));

    printf("-       "); printf(PCOLOR(C)"*          *   *                *****"); printf(PCOLOR(V)"               -\n"); printf(PCOLOR(Y));

    printf("-                                                           -\n"); printf(PCOLOR(V));

    printf("-                                                           -\n"); printf(PCOLOR(Y));

    printf("-                                                           -\n"); printf(PCOLOR(V));

    printf("-                                                           -\n"); printf(PCOLOR(Y));

    printf("-                    "); printf(PCOLOR(C)"Press Enter"); printf(PCOLOR(Y)"                            -\n"); printf(PCOLOR(V));

    printf("-                    "); printf(PCOLOR(C)"to continue"); printf(PCOLOR(V)"                            -\n"); printf(PCOLOR(Y));

    printf("-                                                           -\n"); printf(PCOLOR(V));

    printf("-                                                           -\n"); printf(PCOLOR(Y));

    printf("-------------------------------------------------------------\n"); printf(PCOLOR(S));

    scanfChar(&buffer);
    return 0;
   }


