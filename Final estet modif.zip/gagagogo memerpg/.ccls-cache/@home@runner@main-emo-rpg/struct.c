#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#define S "0"//reSet color
#define L "1"//add light to the color
#define D "2"//assombrie les caractère
#define E "22"//anule les effet L et D
#define V "31"//rouge car R est déja pris
#define G "32"//vert 
#define Y "33"//jaune
#define B "34"//bleu 
#define M "35"//magenta
#define C "36"//cyan
#define W "37"//blanc

#define PCOLOR(X) "\x1b["X"m" //macro pour ajouter la couleur facilement, le X est l'emplacement du code couleur, au forma "nombre"

#define VI "     " //vide de la largeur d'une carte
#define CH "┌   ┐" //partie aute de la carte 
#define CMR "  "   //partie droite de la carte 
#define CML "  "   //partie gauche de la carte 
#define CB "└   ┘" //partie basse de la carte

#define LARG 5
/*
i1 j1 i2 j1
i1 j2 i2 j2
*/
typedef short boolean;
typedef struct {
    int x;
    int y;
}placement;
//type def des struct, self explenatory
typedef struct {
    char skin;
    short color;
    //ajouter des truck ici pour géré les condition de victoire
}item;

typedef struct {
    char name[20];
    placement position;
    short color;
    
    char Race;
    int inventaireArme;
    char inventaireItem;
    char armeSelect;
    //ajouter des truck ici pour géré les sauvegarde, les nom, les condition de victoire, ect...
}player;

typedef struct {
    int reveal;//=1 si la carte a été retourner
    int isfull;//=1 is la carte n'est pas vide
    char content;// /!\ a implémenter dans affichage :effet sur la couleur : 1 iluminé, 2 assombrie, 22 anule les effet 1 et 2, 5 clignotant(ne fonctionne pas en émulateur), 25 annule le clignotement 
    short colorIn;//couleur du content en case 1, effet en case 2
    short colorOut;//couleur de l'exterieur en case 1, effet en case 2
    short back;//couleur de l'arière plan (not in use right now)
}carte;