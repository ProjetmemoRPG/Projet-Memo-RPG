#include "maper.h"
//#include "verif.h"

void resetMap(carte** map1, carte** map2);

//fonction charger de récupérer la direction entré par le joueur
char myDirection(short* tempPos);

//fonction charger de séléctionner une carte sur le tableau et qui renvoi les coordoner de cette dernière
placement select_card(player pl,carte** map);

//fonction qui permet le déplacement du joueur sur la carte dans le respect des règle
void moving(player* plP, carte** map);

//fonction permetent d'échanger 2 carte du tableau
void swap(carte** map,player* plP);

//fonction renvoyant 1 si le joueur est entouré de case révélé
short surrounded(carte** map,player pl);

//fonction jouant le tour du joueur rentré en paramètre
//short turn(player* plP, carte** map);