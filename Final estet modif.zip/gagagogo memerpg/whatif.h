#include "mapper.h"

void choixRace(player* bob);

void choixArme(player* bob);

int Combat(player* bob, char contenuCase, carte** mainMap);

int armeAntique(player* bob, char contenuCase);

int Coffre(player* bob, char contenuCase);

int restart();

int finDujeu(player* bob);

void croixDirectionnelle();

int ecranTitre();

