#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#define S "0"//reSet color
#define L "1"//add light to the color
#define D "2"//assombrie les caractère
#define E "22"//anule les effet L et D
#define V "31"//rouge car R est déja pris
#define G "32"//vert 
#define Y "33"//jaune
#define B "34"//bleu 
#define M "35"//magenta
#define C "36"//cyan
#define W "37"//blanc

#define PCOLOR(X) "\x1b["X"m" //macro pour ajouter la couleur facilement, le X est l'emplacement du code couleur, au forma "nombre"

#define VI "     " //vide de la largeur d'une carte
#define CH "┌   ┐" //partie aute de la carte 
#define CMR "  "   //partie droite de la carte 
#define CML "  "   //partie gauche de la carte 
#define CB "└   ┘" //partie basse de la carte

#define LARG 5
/*
i1 j1 i2 j1
i1 j2 i2 j2
*/
typedef short boolean;
typedef struct {
    int x;
    int y;
}placement;
//type def des struct, self explenatory
typedef struct {
    char skin;
    short color;
    //ajouter des truck ici pour géré les condition de victoire
}item;

typedef struct {
    char name[20];
    placement position;
    short color;
    
    char Race;
    int inventaireArme;
    char inventaireItem;
    char armeSelect;
    //ajouter des truck ici pour géré les sauvegarde, les nom, les condition de victoire, ect...
}player;

typedef struct {
    int reveal;//=1 si la carte a été retourner
    int isfull;//=1 is la carte n'est pas vide
    char content;// /!\ a implémenter dans affichage :effet sur la couleur : 1 iluminé, 2 assombrie, 22 anule les effet 1 et 2, 5 clignotant(ne fonctionne pas en émulateur), 25 annule le clignotement 
    short colorIn;//couleur du content en case 1, effet en case 2
    short colorOut;//couleur de l'exterieur en case 1, effet en case 2
    short back;//couleur de l'arière plan (not in use right now)
}carte;

void resetColor(){
    printf(PCOLOR(S";"E));
}

//affichage, c une purge chercher pas le comprendre en vrai 
void afichage(carte** world,player* plP){
    int n = LARG;
    int j,i;
    resetColor();
    //printf("Tours de %s",(*plP).name[0]);
    //carte joueur 2
    for(i=0;i<(n-1);i++){
        printf(VI);
        resetColor();
    }
    printf(PCOLOR("%d")CH,96);
    printf("\n");
    for(i=0;i<(n-1);i++){
        printf(VI);
        resetColor();
    }
    printf(PCOLOR("%d")CMR,96);
    printf(PCOLOR("%d")"~",96);
    printf(PCOLOR("%d")CML,96);
    printf("\n");
    resetColor();
    for(i=0;i<(n-1);i++){
        printf(VI);
        resetColor();
    }
    printf(PCOLOR("%d")CB,96);
    resetColor();
    //debut affichage worldleau
    for(j=0;j<n;j++){
        printf("\n");
        //haut carte joueur 1
        if(j==1){
            printf(PCOLOR("%d")CH,92);
            resetColor();
        }
        else{
            printf(VI);
        }
        //haut des carte classique
        for(i=0;i<n;i++){
            printf(PCOLOR("%d")CH,world[i][j].colorOut);
        }
        resetColor();
        //haut carte J3
        if(j==(n-2)){
            printf(PCOLOR("%d")CH,94);
            resetColor();
        }
        printf("\n");
        
        //mid carte J1
        if(j==1){
            printf(PCOLOR("%d")CMR,92);
            printf(PCOLOR("%d")"~",92);
            printf(PCOLOR("%d")CML,92);
            resetColor();
        }
        else{
            printf(VI);
        }
        //mid des carte classique
        for(i=0;i<n;i++){
                printf(PCOLOR("%d")CMR,world[j][i].colorOut);
                resetColor();
                if((world[i][j].reveal)!=0){
                    printf(PCOLOR("%d")"%c",world[j][i].colorIn,world[j][i].content);
                    resetColor();
                }
                else{
                    printf(PCOLOR("%d")"🗡️",world[j][i].colorOut);
                    resetColor();
                }
                printf(PCOLOR("%d")CML,world[i][j].colorOut);
                resetColor();
        }
        resetColor();
        //mid carte J3
        if(j==(n-2)){
            printf(PCOLOR("%d")CMR,94);
            printf(PCOLOR("%d")"~",94);
            printf(PCOLOR("%d")CML,94);
            resetColor();
        }
        
        printf("\n");
        
        //Bas carte J1
        if(j==1){
            printf(PCOLOR("%d")CB,92);
            resetColor();
        }
        else{
            printf(VI);
        }
        //bas des carte classiqu
        for(i=0;i<n;i++){
            printf(PCOLOR("%d")CB,world[i][j].colorOut);
            resetColor();
        }
        //bas carte J3
        if(j==(n-2)){
            printf(PCOLOR("%d")CB,94);
            resetColor();
        }
        
    }
    printf("\n");
    
    //carte J4
    for(i=0;i<2;i++){
        printf(VI);
    }
    resetColor();
    printf(PCOLOR("%d")CH,95);
    printf("\n");
    resetColor();
    for(i=0;i<2;i++){
        printf(VI);
    }
    printf(PCOLOR("%d")CMR,95);
    printf(PCOLOR("%d")"~",95);
    printf(PCOLOR("%d")CML,95);
    printf("\n");
    for(i=0;i<2;i++){
        printf(VI);
    }
    printf(PCOLOR("%d")CB,95);
    printf("\n");
    resetColor();
}

