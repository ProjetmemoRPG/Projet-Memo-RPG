#include "base.h"

typedef short boolean;
typedef struct {
    int x;
    int y;
}placement;
//type def des struct, self explenatory
typedef struct {
    char skin;
    short color;
    //ajouter des truck ici pour géré les condition de victoire
}item;

typedef struct {
    char name[20];
    placement position;
    short color;
    
    char Race;
    int inventaireArme;
    char inventaireItem;
    char armeSelect;
    //ajouter des truck ici pour géré les sauvegarde, les nom, les condition de victoire, ect...
}player;

typedef struct {
    int reveal;//=1 si la carte a été retourner
    int isfull;//=1 is la carte n'est pas vide
    char content;// /!\ a implémenter dans affichage :effet sur la couleur : 1 iluminé, 2 assombrie, 22 anule les effet 1 et 2, 5 clignotant(ne fonctionne pas en émulateur), 25 annule le clignotement 
    short colorIn;//couleur du content en case 1, effet en case 2
    short colorOut;//couleur de l'exterieur en case 1, effet en case 2
    short back;//couleur de l'arière plan (not in use right now)
}carte;

void resetColor(){
    printf(PCOLOR(S";"E));
}

//affichage, c une purge chercher pas le comprendre en vrai 
void afichage(carte** world,player* plP){
    int n = LARG;
    int j,i;
    resetColor();
    //printf("Tours de %s",(*plP).name[0]);
    //carte joueur 2
    for(i=0;i<(n-1);i++){
        printf(VI);
        resetColor();
    }
    printf(PCOLOR("%d")CH,96);
    printf("\n");
    for(i=0;i<(n-1);i++){
        printf(VI);
        resetColor();
    }
    printf(PCOLOR("%d")CMR,96);
    printf(PCOLOR("%d")"~",96);
    printf(PCOLOR("%d")CML,96);
    printf("\n");
    resetColor();
    for(i=0;i<(n-1);i++){
        printf(VI);
        resetColor();
    }
    printf(PCOLOR("%d")CB,96);
    resetColor();
    //debut affichage worldleau
    for(j=0;j<n;j++){
        printf("\n");
        //haut carte joueur 1
        if(j==1){
            printf(PCOLOR("%d")CH,92);
            resetColor();
        }
        else{
            printf(VI);
        }
        //haut des carte classique
        for(i=0;i<n;i++){
            printf(PCOLOR("%d")CH,world[i][j].colorOut);
        }
        resetColor();
        //haut carte J3
        if(j==(n-2)){
            printf(PCOLOR("%d")CH,94);
            resetColor();
        }
        printf("\n");
        
        //mid carte J1
        if(j==1){
            printf(PCOLOR("%d")CMR,92);
            printf(PCOLOR("%d")"~",92);
            printf(PCOLOR("%d")CML,92);
            resetColor();
        }
        else{
            printf(VI);
        }
        //mid des carte classique
        for(i=0;i<n;i++){
                printf(PCOLOR("%d")CMR,world[j][i].colorOut);
                resetColor();
                if((world[i][j].reveal)!=0){
                    printf(PCOLOR("%d")"%c",world[j][i].colorIn,world[j][i].content);
                    resetColor();
                }
                else{
                    printf(PCOLOR("%d")"🗡️",world[j][i].colorOut);
                    resetColor();
                }
                printf(PCOLOR("%d")CML,world[i][j].colorOut);
                resetColor();
        }
        resetColor();
        //mid carte J3
        if(j==(n-2)){
            printf(PCOLOR("%d")CMR,94);
            printf(PCOLOR("%d")"~",94);
            printf(PCOLOR("%d")CML,94);
            resetColor();
        }
        
        printf("\n");
        
        //Bas carte J1
        if(j==1){
            printf(PCOLOR("%d")CB,92);
            resetColor();
        }
        else{
            printf(VI);
        }
        //bas des carte classiqu
        for(i=0;i<n;i++){
            printf(PCOLOR("%d")CB,world[i][j].colorOut);
            resetColor();
        }
        //bas carte J3
        if(j==(n-2)){
            printf(PCOLOR("%d")CB,94);
            resetColor();
        }
        
    }
    printf("\n");
    
    //carte J4
    for(i=0;i<2;i++){
        printf(VI);
    }
    resetColor();
    printf(PCOLOR("%d")CH,95);
    printf("\n");
    resetColor();
    for(i=0;i<2;i++){
        printf(VI);
    }
    printf(PCOLOR("%d")CMR,95);
    printf(PCOLOR("%d")"~",95);
    printf(PCOLOR("%d")CML,95);
    printf("\n");
    for(i=0;i<2;i++){
        printf(VI);
    }
    printf(PCOLOR("%d")CB,95);
    printf("\n");
    resetColor();
}

//créer un worldleau de n*n carte +les 4 case de départ des joueur et les rempli de vide (ou de ~ pour les case de départ)
carte** mapSpawning(int n){
    int i,j;
    carte navigo;//créer une carte vide pour remplire le worldleau
    navigo.reveal=1;
    navigo.isfull=0;
    navigo.content='0';
    navigo.colorIn=0;
    navigo.colorOut=37;
    carte** map = malloc(n*(sizeof(carte*)));
    for(i=0;i<n;i++){
        map[i] = malloc(n*sizeof(carte));
        for (j=0;j<n;j++){
           map[i][j] = navigo;
           printf("%d , %d\n",i,j);
           printf(" %c\n",map[i][j].content);
        }
    }
    printf("%d adresse\n\n",map);
    return map;
}

void itemList_creator(item itemList[LARG*LARG]){
    int i = 0;
    for(i=0;i<4;i++){
        itemList[i].skin='Z';//zombies
        itemList[i].color=91;
    }
    for(i=4;i<8;i++){
        itemList[i].skin='T';//troll
        itemList[i].color=91;
    }
    for(i=8;i<12;i++){
        itemList[i].skin='B';//bazilic
        itemList[i].color=91;
    }
    for(i=12;i<16;i++){
        itemList[i].skin='H';//harpies
        itemList[i].color=91;
    }
    for(i=16;i<18;i++){
        itemList[i].skin='C';//cofre
        itemList[i].color=33;
    }
    for(i=18;i<20;i++){
        itemList[i].skin='t';//toteme
        itemList[i].color=35;
    }
    i=20;
    itemList[i].skin='P';//(portail)
    itemList[i].color=34;
    i++;
    itemList[i].skin='S';//stick (baton de controle)
    itemList[i].color=32;
    i++;
    itemList[i].skin='G';//grimoire
    itemList[i].color=36;
    i++;
    itemList[i].skin='D';//dague du someil
    itemList[i].color=95;
    i++;
    itemList[i].skin='E';//épé de feu
    itemList[i].color=94;
}

//prend une carte aléatoir et met dedans un élément de itemList[] et répette l'opération pour chaque élément de itemList
void mapFeeding(carte** map,int nMap,item* itemList,int nList){
    int i,j,carteNb1,carteNb2;
    time_t t;
    printf("entrer feeding\n");
    for(i=0;i<LARG;i++){
        for (j = 0;j<LARG;j++){
           printf("%d , %d",i,j);
           printf(" %c ",map[i][j].content);
           printf("%d; ",map[i][j].reveal);
        }
        printf("\n");
    }
    srand((unsigned) time(&t));
    for (i = 0; i < nList; i++){
        do{
            carteNb1 = rand ()% (nMap);
            carteNb2 = rand ()% (nMap);
        }while(map[carteNb1][carteNb2].isfull != 0);
        map[carteNb1][carteNb2].content = itemList[i].skin;
        map[carteNb1][carteNb2].colorIn = itemList[i].color;
        map[carteNb1][carteNb2].isfull = 1;
    }
    
    printf("feed\n");
    for(i=0;i<LARG;i++){
        for (j = 0;j<LARG;j++){
           printf("%d , %d",i,j);
           printf(" %c ",map[i][j].content);
           printf("%d; ",map[i][j].reveal);
        }
        printf("\n");
    }
    
}

player playerCreator(){
    char name[] = "bernard";
    player pl;
    pl.position.x = 1;
    pl.position.y = 1;
    pl.color = 31;
  /*
    pl.name[0] = 'B';
    pl.name[1] = '\0';
    choixRace(Joueur* bob);
    
}

char myDirection(short* tempPos){
    char input;
    printf("choisicer une direction :");
    scanf("%c",&input);
    return input;
}

placement select_card(player pl,carte** map){
    placement selectPosition = pl.position;
    short* p = &selectPosition;
    char input = 0;
    do{
        afichage(map,&pl);
        croixDirectionnelle();
        input = myDirection(p);
        (map[selectPosition.x][selectPosition.y]).colorOut = 0;
        
        if(input == 'z'){
            if((selectPosition.y-1)>=0){
                printf("%d",selectPosition.y-1);
                selectPosition.y--;
            }
        }
        else if(input == 's'){
            if((selectPosition.y+1)<=LARG){
                printf("%d",selectPosition.y+1);
                selectPosition.y++;
            }  
        }
        else if(input == 'q'){
            if((selectPosition.x-1)>=0){
                printf("%d",selectPosition.x-1);
                selectPosition.x--;
            }
        }
        else if(input == 'd'){
            if((selectPosition.x+1)<LARG){
                printf("%d",selectPosition.x+1);
                selectPosition.x++;
            }
        }
        
        printf("%c",input);
        (map[selectPosition.x][selectPosition.y]).colorOut = pl.color;
    }while(input != ' ');
    
    return selectPosition;
}


void deplacement(player* plP, carte** map){
    player pl = *plP;
    short endMooving = 0;
    placement posTemp;
    do{
        posTemp = mooving(pl, map);
        if(((pl.position.x - posTemp.x)==0)&&((pl.position.y - posTemp.y)==0)){
            printf("position selctioner identique, recomencer");
        }
        else if(map[pl.position.x][pl.position.y].content != 'P'){
            if((abs(pl.position.x - posTemp.x)!=1)||(abs(pl.position.y - posTemp.y)!=1)){
                printf("position non valide, recomencer");
            }
        }
        else{
            endMooving=1;
            (*plP).position = posTemp;
        }
    }while(endMooving==0);
    map[pl.position.x][pl.position.y].reveal = 1;
}


void swap(carte** map,player* plP){
    player fictivPlayer;//variable nécésaire a la séléction des case, pour indiquer a select_card ou commencer
    fictivPlayer.position.x=0;
    fictivPlayer.position.y=0;
    short exitCondition;
    carte tempCarte;
    placement position1, position2;
    
    printf("Vous avez découvert un totem! choiscer les 2 case a échanger entre elle");
    do{
        exitCondition = 1;
        position1 = select_card(fictivPlayer,map); //selectionne les 2 position
        position2 = select_card(fictivPlayer,map);
        if((position1.x == position2.x)&&(position1.y == position2.y)){ //vérifie si les 2 case sont pas les meme (peut etre retirer, ca fonctionnera quand meme, juste on poura ne pas swap)
            exitCondition = 0;
            printf("vous avez séléctioner les 2 meme case. veuiller recomencer");
        }
        else{ //effectue le swap
            tempCarte = map[position1.x][position1.y];
            map[position1.x][position1.y] = map[position2.x][position2.y];
            map[position2.x][position2.y] = tempCarte;
        }
        if((position1.x == (*plP).position.x)&&(position1.y == (*plP).position.y)){ //change la posistion du joueur si il est sur la case swaper
            (*plP).position = position2;
        }
        else if((position2.x == (*plP).position.x)&&(position2.y == (*plP).position.y)){
            (*plP).position = position1;
        }
    }while(exitCondition == 1);
}

surrounded(carte** map,player pl){
    if((map[pl.position.x][pl.position.y-1].reveal == 1)&&(map[pl.position.x-1][pl.position.y].reveal == 1)&&(map[pl.position.x][pl.position.y+1].reveal == 1)&&(map[pl.position.x+1][pl.position.y].reveal == 1)){
        return 1;
    }
    else{
        return 0;
    }
}
/*
short turn(player* plP, carte** map){
    player pl = *plP;
    short end_turn = 0;
    do{
        affichage(map, plP);
        choixArme(Joueur* bob);
        deplacement(plP,map);
        
        if(map[pl.position.x][pl.position.y].content == 't'){
            swap(map,plP);
        }
        if((combat(plP,map) == 0){
            end_turn = 1;
        }
        if(surrounded(map, *plP) == 1){
            end_turn = 1
        }
        
    }while(end_turn == 0);
    
    return  finDujeu(plP);
}
*/
void free_map(carte** map){
    int i;
    for(i=0;i<n;i++){
        free(map[i]);
    }
    free(map);
}

void resetMap(carte** map1, carte** map2){
    for(int i=0;i<LARG;i++){
        for (int j = 0;j<LARG;j++){
            map1[i][j] = map2[i][j]; 
        }
    }
}

//ca c le main, rien de pârticulier a par que ya que des valeur de teste pour le moment
int main()
{
    printf("Booting up icredible game\n");
    
    int i,j;
    char test[25];
    carte** littmap;
    item itemList[LARG*LARG];
    
    itemList_creator(itemList);
    littmap = mapSpawning(LARG);
    printf("main️\n");
    for(i=0;i<LARG;i++){
        for (j = 0;j<LARG;j++){
           printf("%d , %d",i,j);
           printf(" %c ",littmap[i][j].content);
           printf("%d; ",littmap[i][j].reveal);
        }
        printf("\n");
    }
    player pl1=playerCreator();
    player* pl1P = &pl1;
    mapFeeding(littmap,LARG,itemList,LARG*LARG);
    
    printf("main🗡️\n");
    for(i=0;i<LARG;i++){
        for (j = 0;j<LARG;j++){
           printf("%d , %d",i,j);
           printf(" %c ",littmap[i][j].content);
           printf("%d; ",littmap[i][j].reveal);
        }
        printf("\n");
    }
    afichage(littmap,pl1P);
    
    //mooving(pl,littmap,LARG);
    
    printf("tes");
    int testvalue;
    return errno;
}
/*
int main(){
    char buffer;
    short victory;
    int nbPlayer;
    player listPlayer[nbPlayer];
    item itemList[LARG*LARG];
    itemList_creator(itemList);
    int i,j;
    
    title_screen();
    
    scanf("%c",&buffer);
    
    for(i=0;i<nbPlayer;i++){
        listPlayer[i] = playerCreator();
    }
    
    do{
        creat** mainMap = mapSpawning();
        creat** saveMap = mapSpawning();
        mapFeeding(saveMap,LARG,itemList,LARG*LARG);
        resetMap(mainMap,saveMap);
        i=0;
        victory=0;
        
        do{
            victory = turn(listPlayer+i,mainMap);
            i++
            if(i>=4){
                i = 0;
            }
            resetMap(mainMap,saveMap);
        }while(victory == 0);
        printf("%s, le joueur %d a gagner",listPlayer[i].name,i);
        save();
        max_score();
        free_map(mainMap);
    }while(restart()==1);

    
}

*/
