#include "maper.h"


void resetMap(carte** map1, carte** map2){
    for(int i=0;i<LARG;i++){
        for (int j = 0;j<LARG;j++){
            map1[i][j] = map2[i][j]; 
        }
    }
}


char myDirection(placement* tempPos){
    char input;
    printf("choisicer une direction :");
    scanf("%c",&input);
    return input;
}

placement select_card(player pl,carte** map){
    placement selectPosition = pl.position;
    placement* p = &selectPosition;
    char input = 0;
    do{
        afichage(map,&pl);
        //croixDirectionnelle();
        input = myDirection(p);
        (map[selectPosition.x][selectPosition.y]).colorOut = 0;
        
        if(input == 'z'){
            if((selectPosition.y-1)>=0){
                printf("%d",selectPosition.y-1);
                selectPosition.y--;
            }
        }
        else if(input == 's'){
            if((selectPosition.y+1)<=LARG){
                printf("%d",selectPosition.y+1);
                selectPosition.y++;
            }  
        }
        else if(input == 'q'){
            if((selectPosition.x-1)>=0){
                printf("%d",selectPosition.x-1);
                selectPosition.x--;
            }
        }
        else if(input == 'd'){
            if((selectPosition.x+1)<LARG){
                printf("%d",selectPosition.x+1);
                selectPosition.x++;
            }
        }
        
        printf("%c",input);
        (map[selectPosition.x][selectPosition.y]).colorOut = pl.color;
    }while(input != ' ');
    
    return selectPosition;
}


void moving(player* plP, carte** map){
    player pl = *plP;
    short endMooving = 0;
    placement posTemp;
    do{
        posTemp = select_card(pl, map);
        if(((pl.position.x - posTemp.x)==0)&&((pl.position.y - posTemp.y)==0)){
            printf("position selctioner identique, recomencer");
        }
        else if(map[pl.position.x][pl.position.y].content != 'P'){
            if((abs(pl.position.x - posTemp.x)!=1)||(abs(pl.position.y - posTemp.y)!=1)){
                printf("position non valide, recomencer");
            }
        }
        else{
            endMooving=1;
            (*plP).position = posTemp;
        }
    }while(endMooving==0);
    map[pl.position.x][pl.position.y].reveal = 1;
}


void swap(carte** map,player* plP){
    player fictivPlayer;//variable nécésaire a la séléction des case, pour indiquer a select_card ou commencer
    fictivPlayer.position.x=0;
    fictivPlayer.position.y=0;
    short exitCondition;
    carte tempCarte;
    placement position1, position2;
    
    printf("Vous avez découvert un totem! choiscer les 2 case a échanger entre elle");
    do{
        exitCondition = 1;
        position1 = select_card(fictivPlayer,map); //selectionne les 2 position
        position2 = select_card(fictivPlayer,map);
        if((position1.x == position2.x)&&(position1.y == position2.y)){ //vérifie si les 2 case sont pas les meme (peut etre retirer, ca fonctionnera quand meme, juste on poura ne pas swap)
            exitCondition = 0;
            printf("vous avez séléctioner les 2 meme case. veuiller recomencer");
        }
        else{ //effectue le swap
            tempCarte = map[position1.x][position1.y];
            map[position1.x][position1.y] = map[position2.x][position2.y];
            map[position2.x][position2.y] = tempCarte;
        }
        if((position1.x == (*plP).position.x)&&(position1.y == (*plP).position.y)){ //change la posistion du joueur si il est sur la case swaper
            (*plP).position = position2;
        }
        else if((position2.x == (*plP).position.x)&&(position2.y == (*plP).position.y)){
            (*plP).position = position1;
        }
    }while(exitCondition == 1);
}

short surrounded(carte** map,player pl){
    if((map[pl.position.x][pl.position.y-1].reveal == 1)&&(map[pl.position.x-1][pl.position.y].reveal == 1)&&(map[pl.position.x][pl.position.y+1].reveal == 1)&&(map[pl.position.x+1][pl.position.y].reveal == 1)){
        return 1;
    }
    else{
        return 0;
    }
}

short turn(player* plP, carte** map){
    player pl = *plP;//player Pointer
    short end_turn = 0;
    do{
        afichage(map, plP);
        choixArme(plP);
        moving(plP,map);
        
        if(map[pl.position.x][pl.position.y].content == 't'){
            swap(map,plP);
        }
        if(Combat(plP,(map[pl.position.x][pl.position.y]).content,map) == 0){
            end_turn = 1;
        }
        if(surrounded(map, *plP) == 1){
            end_turn = 1;
        }
        
    }while(end_turn == 0);
    
    return  finDujeu(plP);
}
