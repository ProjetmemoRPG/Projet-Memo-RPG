#include "whatif.h"


void resetColor();

// affichage, c une purge chercher pas le comprendre en vrai
void afichage(carte **world, player *plP);
// créer un worldleau de n*n carte
carte **mapSpawning(int n);
// créer le tableau de tout les item a metre dans la map
void itemList_creator(item itemList[LARG * LARG]);
// prend une carte aléatoir et met dedans un élément de itemList[] et répette l'opération pour chaque élément de itemList
void mapFeeding(carte **map, int nMap, item *itemList, int nList);

void free_map(carte** map);
