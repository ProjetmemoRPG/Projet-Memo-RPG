#include "gamplay.h"



player playerCreator(){
    char name[] = "bernard";
    player pl;
    pl.position.x = 1;
    pl.position.y = 1;
    pl.color = 31;
  /*
    pl.name[0] = 'B';
    pl.name[1] = '\0';
    choixRace(Joueur* bob);
*/  
}

/*
//ca c le main, rien de pârticulier a par que ya que des valeur de teste pour le moment
int main()
{
    printf("Booting up icredible game\n");
    
    int i,j;
    char test[25];
    carte** littmap;
    item itemList[LARG*LARG];
    
    itemList_creator(itemList);
    littmap = mapSpawning(LARG);
    printf("main️\n");
    for(i=0;i<LARG;i++){
        for (j = 0;j<LARG;j++){
           printf("%d , %d",i,j);
           printf(" %c ",littmap[i][j].content);
           printf("%d; ",littmap[i][j].reveal);
        }
        printf("\n");
    }
    player pl1=playerCreator();
    player* pl1P = &pl1;
    mapFeeding(littmap,LARG,itemList,LARG*LARG);
    
    printf("main🗡️\n");
    for(i=0;i<LARG;i++){
        for (j = 0;j<LARG;j++){
           printf("%d , %d",i,j);
           printf(" %c ",littmap[i][j].content);
           printf("%d; ",littmap[i][j].reveal);
        }
        printf("\n");
    }
    afichage(littmap,pl1P);
    
    //mooving(pl,littmap,LARG);
    
    printf("tes");
    int testvalue;
    return errno;
}
*/

int main(){
    printf("like start");
    char buffer;
    short victory;
    int nbPlayer;
    player listPlayer[nbPlayer];
    item itemList[LARG*LARG];
    itemList_creator(itemList);
    int i,j;
    
    ecranTitre();
    
    scanf("%c",&buffer);
    
    for(i=0;i<nbPlayer;i++){
        listPlayer[i] = playerCreator();
    }
    
    do{
        carte** mainMap = mapSpawning(LARG);
        carte** saveMap = mapSpawning(LARG);
        mapFeeding(saveMap,LARG,itemList,LARG*LARG);
        resetMap(mainMap,saveMap);
        i=0;
        victory=0;
        
        do{
            victory = turn(listPlayer+i,mainMap);
            i++;
            if(i>=4){
                i = 0;
            }
            resetMap(mainMap,saveMap);
        }while(victory == 0);
        printf("%s, le joueur %d a gagner",listPlayer[i].name,i);
        //save();
        //max_score();
        free_map(mainMap);
    }while(restart()==1);

    
}


