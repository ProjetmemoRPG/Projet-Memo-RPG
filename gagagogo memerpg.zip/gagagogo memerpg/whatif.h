#include "base.h"


void choixRace(player* bob);

void choixArme(player* bob);

int Combat(player* bob, char contenuCase, carte** mainMap);

int armeAntique(player* bob, char contenuCase);

int Coffre(player* bob, char contenuCase);

int finDujeu(player* bob);

int restart();

void croixDirectionnelle();

int ecranTitre();
